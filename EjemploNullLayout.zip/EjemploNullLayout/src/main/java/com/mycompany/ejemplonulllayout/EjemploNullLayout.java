/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejemplonulllayout;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JFrame;

/**
 *
 * @author Eduardo
 */
public class EjemploNullLayout {
    public static void añadircomponentes(Container pane) {
        pane.setLayout(null);
 
        JButton b1 = new JButton("BOTON1");
        JButton b2 = new JButton("BOTON 2");
        JButton b3 = new JButton("BOTON 3");
 
        pane.add(b1);
        pane.add(b2);
        pane.add(b3);
 
        Insets insets = pane.getInsets();
        Dimension size = b1.getPreferredSize();
        b1.setBounds(40 + insets.left, 5 + insets.top,
                     size.width, size.height + 10);
        size = b2.getPreferredSize();
        b2.setBounds(15 + insets.left, 70 + insets.top,
                     size.width + 60, size.height);
        size = b3.getPreferredSize();
        b3.setBounds(140 + insets.left, 20 + insets.top,
                     size.width + 50, size.height + 20);
    }

    private static void crearGUI() {
        JFrame frame = new JFrame("Ejemplo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        añadircomponentes(frame.getContentPane());
        Insets insets = frame.getInsets();
        frame.setSize(300 + insets.left + insets.right,
                      140 + insets.top + insets.bottom);
        frame.setVisible(true);
    }
 
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                crearGUI();
            }
        });
    }
}
