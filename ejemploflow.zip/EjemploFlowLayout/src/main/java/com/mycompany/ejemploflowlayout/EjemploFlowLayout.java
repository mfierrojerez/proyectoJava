/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejemploflowlayout;

import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author Eduardo
 */
public class EjemploFlowLayout {

    public static void main(String[] args) {

        JFrame frame = new JFrame("EJEMPLO");
        JButton btn1 = new JButton("BOTON 1");
        JButton btn2 = new JButton("BOTON 2");
        JButton btn3 = new JButton("BOTON 3");
        JButton btn4 = new JButton("BOTON 4");
        JButton btn5 = new JButton("BOTON 5");
        // FlowLayout is default for JPanel
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        // add buttons to the panel
        panel.add(btn1);
        panel.add(btn2);
        panel.add(btn3);
        panel.add(btn4);
        panel.add(btn5);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300,150);
        frame.getContentPane().add(panel);
        frame.setVisible(true);
    }
}
